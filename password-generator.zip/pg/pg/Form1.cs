﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int totallen = 15;
            const string totalCHAR= "~`!@#$%^&*()_+=/*-+abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

            StringBuilder result = new StringBuilder();
            Random randomTXT = new Random();
            while (0<totallen--)
            {
                result.Append(totalCHAR[randomTXT.Next(totalCHAR.Length)]);
            }
            textBox1.Text = result.ToString();
        }
    }
}
